# Lumyn SDK C v4.1.0 - windows-x64

Pre-built C SDK for Lumyn Labs ConnectorX devices.

## Contents

- `include/` - SDK header files
- `lib/` - Pre-built library (shared/static)
- `examples/` - Example programs and config files
- `CMakeLists.txt` - Build configuration for examples

## Quick Start

### Building the Examples

```bash
# Create build directory and configure
mkdir build && cd build
cmake ..

# Build all examples
cmake --build .

# Or build a specific example
cmake --build . --target quickstart
```

### Running an Example

```bash
# Linux
./quickstart --port /dev/ttyACM0

# Windows
./quickstart.exe --port COM3

# List available ports
./port_scan
```

## Integrating into Your Project

### Option 1: CMake (Recommended)

Add to your CMakeLists.txt:

```cmake
# Set path to SDK
set(LUMYN_SDK_DIR "/path/to/lumyn-sdk-c-v4.1.0-windows-x64")

# Include headers
include_directories(${LUMYN_SDK_DIR}/include)

# Link library
find_library(LUMYN_SDK_C lumyn_sdk_c PATHS ${LUMYN_SDK_DIR}/lib REQUIRED)
target_link_libraries(your_target PRIVATE ${LUMYN_SDK_C})
```

### Option 2: Manual Compilation

```bash
# Linux
gcc -I/path/to/sdk/include your_program.c -L/path/to/sdk/lib -llumyn_sdk_c -o your_program

# Windows (MSVC)
cl /I"C:\path\to\sdk\include" your_program.c /link /LIBPATH:"C:\path\to\sdk\lib" lumyn_sdk_c.lib
```

## Examples Overview

| Example | Description |
|---------|-------------|
| `quickstart` | Quick start - connection, animations, DirectLED |
| `connectorx_basic` | Comprehensive single-channel usage |
| `connectorx_animate` | Multi-channel control with ConnectorXAnimate |
| `matrix_text_advanced` | Matrix text with fonts and scrolling |
| `direct_led_patterns` | DirectLED buffer control |
| `modules_typed` | Reading module/sensor data |
| `config_builder_basic` | Creating device configurations |
| `port_scan` | Finding connected devices |

## API Headers

```c
#include <lumyn/c/lumyn_sdk.h>       // Main SDK header
#include <lumyn/types.h>              // Type definitions
```

## Requirements

- C11 compatible compiler
- CMake 3.16+ (for building examples)

## Platform Notes

**Linux:**
- Add user to dialout group: `sudo usermod -a -G dialout $USER`
- May need to set library path: `export LD_LIBRARY_PATH=/path/to/sdk/lib:$LD_LIBRARY_PATH`

**Windows:**
- Ensure lumyn_sdk_c.dll is in PATH or same directory as executable

## Documentation

For full API documentation, visit: https://docs.lumynlabs.com/sdk/c

## Version Information

- SDK Version: 4.1.0
- Platform: windows-x64
- C Standard: C11
