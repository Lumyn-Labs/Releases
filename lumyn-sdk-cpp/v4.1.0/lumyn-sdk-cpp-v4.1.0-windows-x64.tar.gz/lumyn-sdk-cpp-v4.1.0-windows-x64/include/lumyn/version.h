#pragma once

#define LUMYN_VERSION_MAJOR 4
#define LUMYN_VERSION_MINOR 4
#define LUMYN_VERSION_PATCH 0
