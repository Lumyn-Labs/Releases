#pragma once

namespace lumyn {
inline constexpr int VersionMajor = 4;
inline constexpr int VersionMinor = 1;
inline constexpr int VersionPatch = 0;
inline constexpr const char* Version = "4.1.0";
} // namespace lumyn
