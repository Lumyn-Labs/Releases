# Lumyn SDK C++ v4.1.0 - linux-x64

Pre-built C++ SDK for Lumyn Labs ConnectorX devices.

## Contents

- `include/` - SDK header files
- `lib/` - Pre-built library (shared/static)
- `examples/` - Example programs and config files
- `CMakeLists.txt` - Build configuration for examples

## Quick Start

### Building the Examples

```bash
# Create build directory and configure
mkdir build && cd build
cmake ..

# Build all examples
cmake --build .

# Or build a specific example
cmake --build . --target quickstart
```

### Running an Example

```bash
# Linux
./quickstart --port /dev/ttyACM0

# Windows
./quickstart.exe --port COM3

# List available ports
./port_scan
```

## Integrating into Your Project

### Option 1: CMake (Recommended)

Add to your CMakeLists.txt:

```cmake
# Set path to SDK
set(LUMYN_SDK_DIR "/path/to/lumyn-sdk-cpp-v4.1.0-linux-x64")

# Include headers (use BEFORE to ensure bundle headers take precedence)
target_include_directories(your_target PRIVATE BEFORE ${LUMYN_SDK_DIR}/include)

# Link library
find_library(LUMYN_SDK_CPP lumyn_sdk_cpp PATHS ${LUMYN_SDK_DIR}/lib REQUIRED)
target_link_libraries(your_target PRIVATE ${LUMYN_SDK_CPP})
```

### Option 2: Manual Compilation

```bash
# Linux
g++ -std=c++20 -I/path/to/sdk/include your_program.cpp -L/path/to/sdk/lib -llumyn_sdk_cpp -o your_program

# Windows (MSVC)
cl /std:c++20 /I"C:\path\to\sdk\include" your_program.cpp /link /LIBPATH:"C:\path\to\sdk\lib" lumyn_sdk_cpp.lib
```

## Examples Overview

| Example | Description |
|---------|-------------|
| `quickstart` | Quick start - connection, animations, DirectLED |
| `connectorx_basic` | Comprehensive single-channel usage |
| `connectorx_animate` | Multi-channel control with ConnectorXAnimate |
| `matrix_text_advanced` | Matrix text with fonts and scrolling |
| `direct_led_patterns` | DirectLED buffer control |
| `screen_mirror` | High-performance screen mirroring |
| `modules_typed` | Reading module/sensor data |
| `config_builder_basic` | Creating device configurations |
| `port_scan` | Finding connected devices |

## API Headers

```cpp
#include <lumyn/cpp/connectorXVariant/ConnectorX.hpp>        // ConnectorX device
#include <lumyn/cpp/connectorXVariant/ConnectorXAnimate.hpp> // ConnectorXAnimate device
#include <lumyn/types.h>                                      // Type definitions
```

## Requirements

- C++20 compatible compiler (GCC 10+, Clang 10+, MSVC 2019+)
- CMake 3.16+ (for building examples)

## Platform Notes

**Linux:**
- Add user to dialout group: `sudo usermod -a -G dialout $USER`
- May need to set library path: `export LD_LIBRARY_PATH=/path/to/sdk/lib:$LD_LIBRARY_PATH`

**Windows:**
- Ensure lumyn_sdk_cpp.dll is in PATH or same directory as executable

## Documentation

For full API documentation, visit: https://docs.lumynlabs.com/sdk/cpp

## Version Information

- SDK Version: 4.1.0
- Platform: linux-x64
- C++ Standard: C++20
